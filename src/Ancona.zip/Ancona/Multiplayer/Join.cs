using System.Numerics;
using LiteNetwork.Client;
using Packing;
using Raylib_cs;

namespace Ancona.Multiplayer;

public class Join
{
    public Client client;
    public Button joinbutton;

    public Join()
    {
        Vector2 size = new Vector2(350, 200);
        
        joinbutton =
            new Button(new Rectangle(Raylib.GetScreenWidth() / 2 - size.X / 2, Raylib.GetScreenHeight() / 2 - size.Y / 2, 
                    size.X, size.Y),
                "Join", 150
            );
    }

    public async Task ConnectToServer()
    {
        
        var options = new LiteClientOptions()
        {
            Host = "127.0.0.1",
            Port = 8493,
            BufferSize = 4096
        };
        
        var client = new Client(options);
        
        Console.WriteLine("Connecting to " + options.Host + ":" + options.Port);
        
        this.client = client;

        await client.ConnectAsync();

        Console.WriteLine(client.Socket.Connected);
        Console.WriteLine(client.Id);
    }

    public void Play()
    {
        if (Raylib.IsCursorHidden())
        {
            Raylib.ShowCursor();
        }
        
        joinbutton.Play();
    }
    public void Work() 
    {
        if(joinbutton.isPressed)
        {
            ConnectToServer();
        }
    }
    public void Draw() 
    {
        joinbutton.Draw(Color.WHITE, 10f);
    }
}