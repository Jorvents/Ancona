using Ancona.Multiplayer;

namespace Ancona;

public class Controller
{
    private Game game = new Game();
    private Join join = new Join();

    public List<Client> clientsideclients;
    public Client myclient;
    private enum Scene
    {
        joining,
        gaming
    }
    Scene scene;

    public Controller()
    {
        scene = Scene.joining;
    }

    public void JustRun()
    {
        Play();
        Work();
        Draw();
    }

    void Play()
    {
        switch (scene)
        {
            case 0:
                join.Play();
                break;
            case (Scene)1:
                game.Play();
                break;
        }
    }
    void Work()
    {
        switch (scene)
        {
            case 0:
                join.Work();
                if (join.joinbutton.isPressed)
                {
                    myclient = join.client;
                    scene = Scene.gaming;
                }
                break;
            case (Scene)1:
                game.Work(myclient);
                break;
        }
    }
    void Draw()
    {
        switch (scene)
        {
            case 0:
                join.Draw();
                break;
            case (Scene)1:
                game.Draw();
                break;
        }
    }
}