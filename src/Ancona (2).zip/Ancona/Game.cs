using System.Numerics;
using Ancona.Multiplayer;
using Raylib_cs;
using static Raylib_cs.CameraProjection;

namespace Ancona;

public class Game
{
    Vector2 rotation = new Vector2();
    
    Camera3D camera = new Camera3D();

    Vector3 offset = new Vector3();
    
    float speed = 0.04f;
    float sensitivity = 500f;
    
    public Game()
    {
        camera.position = new Vector3(0.0f, 5.0f, 0.0f);      // Camera position
        //camera.target = new Vector3(2.0f);                       // Camera looking at point
        camera.up = new Vector3(0.0f, 1.0f, 0.0f);           // Camera up vector (rotation towards target)
        camera.fovy = 80.0f;                                      // Camera field-of-view Y
        camera.projection = CAMERA_PERSPECTIVE;                  // Camera mode type
        
        rotation -= new Vector2(Raylib.GetScreenWidth() / 2, Raylib.GetScreenHeight() / 2);

        camera.position = new Vector3(0.0f, 5.0f, 0.0f);      // Camera position
        //camera.target = new Vector3(2.0f);                       // Camera looking at point
        camera.up = new Vector3(0.0f, 1.0f, 0.0f);           // Camera up vector (rotation towards target)
        camera.fovy = 80.0f;                                      // Camera field-of-view Y
        camera.projection = CAMERA_PERSPECTIVE;                  // Camera mode type
        
        Quaternion quaternion = Quaternion.CreateFromYawPitchRoll(-rotation.X / sensitivity, rotation.Y / sensitivity, 0f);

        offset = Vector3.Transform(new Vector3(0, 0, sensitivity), quaternion);
        camera.target = camera.position + offset;
    }

    public void Play()
    {
        if (!Raylib.IsCursorHidden())
        {
            Raylib.HideCursor();
        }
        
        rotation.X += Raylib.GetMouseDelta().X;
        rotation.Y += Raylib.GetMouseDelta().Y;
        
        Quaternion quaternion = Quaternion.CreateFromYawPitchRoll(-rotation.X / sensitivity, rotation.Y / sensitivity, 0f);

        offset = Vector3.Transform(new Vector3(0, 0, sensitivity), quaternion);
        camera.target = camera.position + offset;
        
        if (Raylib.IsKeyDown(KeyboardKey.KEY_W))
        {
            camera.position.X += Raylib.GetFrameTime() * speed * offset.X;
            camera.position.Z += Raylib.GetFrameTime() * speed * offset.Z;
        }
        if (Raylib.IsKeyDown(KeyboardKey.KEY_S))
        {
            camera.position.X += Raylib.GetFrameTime() * speed * -offset.X;
            camera.position.Z += Raylib.GetFrameTime() * speed * -offset.Z;
        }
        if (Raylib.IsKeyDown(KeyboardKey.KEY_A))
        {
            camera.position.X += Raylib.GetFrameTime() * speed * offset.Z;
            camera.position.Z += Raylib.GetFrameTime() * speed * -offset.X;
        }
        if (Raylib.IsKeyDown(KeyboardKey.KEY_D))
        {
            camera.position.X += Raylib.GetFrameTime() * speed * -offset.Z;
            camera.position.Z += Raylib.GetFrameTime() * speed * offset.X;
        }
        
        if (Raylib.IsKeyDown(KeyboardKey.KEY_SPACE))
        {
            camera.position.Y += Raylib.GetFrameTime() * speed * sensitivity;
        }
        if (Raylib.IsKeyDown(KeyboardKey.KEY_LEFT_SHIFT))
        {
            camera.position.Y += Raylib.GetFrameTime() * speed * -sensitivity;
        }
        
        Raylib.SetMousePosition(Raylib.GetScreenWidth() / 2, Raylib.GetScreenHeight() / 2);
    }
    public void Work(Client myclient)
    {
        
        MemoryStream stream = new MemoryStream();
        BinaryWriter writer = new BinaryWriter(stream);
        writer.Write(myclient.Id + ": " + camera.position);
            
        myclient.Send(stream);
        
        Raylib.UpdateCamera(ref camera);
        
    }
    public void Draw()
    {
        Raylib.BeginMode3D(camera);

        int size = 32;

        Raylib.DrawGrid(size, size / 10f);

        Raylib.DrawLine3D(Vector3.Zero, new Vector3(size, 0f,0f), Color.RED);
        Raylib.DrawLine3D(Vector3.Zero, new Vector3(0f, size,0f), Color.GREEN);
        Raylib.DrawLine3D(Vector3.Zero, new Vector3(0f, 0f,size), Color.BLUE);
                
        //Raylib.DrawSphere(camera.target, 15f, Color.RED);

        Raylib.EndMode3D();
                
        Raylib.DrawText("Rotation: "+rotation.ToString(), 10, 40, 20, Color.DARKGRAY);
        Raylib.DrawText("Posistion: "+camera.position.ToString(), 10, 80, 20, Color.DARKGRAY);
        Raylib.DrawText("Mouse delta: "+Raylib.GetMouseDelta().ToString(), 10, 120, 20, Color.DARKGRAY);
        Raylib.DrawText("Target: " + camera.target.ToString(), 10, 160, 20, Color.DARKGRAY);
        Raylib.DrawText("Offset: "+offset.ToString(), 10, 240, 20, Color.DARKGRAY);
    }
}