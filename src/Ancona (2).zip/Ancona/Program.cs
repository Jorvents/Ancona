﻿using System.Numerics;
using Ancona.Multiplayer;
using Raylib_cs;
using static Raylib_cs.CameraProjection;

namespace Ancona
{
    static class Program
    {
        public static void Main()
        {
            Raylib.InitWindow(1280, 720, "Ancona");
            Raylib.SetTargetFPS(163);
            
            Controller controller = new Controller();
            
            while (!Raylib.WindowShouldClose())
            {
                Raylib.BeginDrawing();

                Raylib.ClearBackground(Color.BLACK);
                
                controller.JustRun();
                
                Raylib.EndDrawing();
            }
            Raylib.CloseWindow();
        }
    }
}