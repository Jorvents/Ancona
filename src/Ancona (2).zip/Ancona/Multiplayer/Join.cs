using System.Numerics;
using LiteNetwork.Client;
using Packing;
using Raylib_cs;

namespace Ancona.Multiplayer;

public class Join
{
    public Client client;
    public Button joinbutton;

    public TextBox textbox;

    public Join()
    {
        Vector2 size = new Vector2(350, 200);

        int spacing = 50;
        int height = 150;
        
        joinbutton =
            new Button(new Rectangle(Raylib.GetScreenWidth() / 2 - size.X / 2, Raylib.GetScreenHeight() / 2 - size.Y / 2, 
                    size.X, size.Y),
                "Join", 150
            );

        textbox = new TextBox(new Rectangle(spacing, Raylib.GetScreenHeight() - spacing - height, Raylib.GetScreenWidth() - spacing * 2, height), 15f, 60);
    }

    public async Task ConnectToServer()
    {
        
        var options = new LiteClientOptions()
        {
            Host = textbox.output,
            Port = 8493,
            BufferSize = 4096
        };
        
        var client = new Client(options);
        
        Console.WriteLine("Connecting to " + options.Host + ":" + options.Port);
        
        this.client = client;

        await client.ConnectAsync();

        Console.WriteLine(client.Socket.Connected);
        Console.WriteLine(client.Id);
    }

    public void Play()
    {
        if (Raylib.IsCursorHidden())
        {
            Raylib.ShowCursor();
        }
        
        joinbutton.Play();
        textbox.Play();
    }
    public void Work() 
    {
        if(joinbutton.isPressed)
        {
            ConnectToServer();
        }
        textbox.Work();
    }
    public void Draw() 
    {
        joinbutton.Draw(Color.WHITE, 10f);
        textbox.Draw(Color.WHITE, Color.PINK);
    }
}