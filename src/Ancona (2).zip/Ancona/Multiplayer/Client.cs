using System.Collections;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using System;
using LiteNetwork.Client;

namespace Ancona.Multiplayer;

public class Client : LiteClient
{
    public Client(LiteClientOptions options, IServiceProvider serviceProvider = null) 
        : base(options, serviceProvider)
    {
        
    }
    public override Task HandleMessageAsync(byte[] packetBuffer)
    {
        // Handle incoming messages using a BinaryReader or any other solution for reading a byte[].
        return null;
    }

    protected override void OnConnected()
    {
        // When the client connects.
    }

    protected override void OnDisconnected()
    {
        // When the client disconnects.
    }
}